const mongoose = require('mongoose')

const Schema = mongoose.Schema;
var LeaveInfo = new Schema({
    intialDate: {
        type: String
    },
    finalDate: {
        type: String
    },
    totalDays: {
        type: String
    },
    reasonForLeave: {
        type: String

    },
    typeofLeave: {
        type: String
    },
    email: {
        type: String
    },
    leaveStatus: {
        type: String
    },
    associateName: {
        type: String
    }






}, { versionKey: false });


module.exports = mongoose.model('LeaveInfo', LeaveInfo);