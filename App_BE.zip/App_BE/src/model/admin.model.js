const mongoose = require('mongoose')

const Schema = mongoose.Schema;
 var Admin = new Schema({
    email: {
        type: String,
        required: true,
    
    
      },
      adminName:{
        type:String,
       
      }
      ,
      password: {
        type: String,
        required: true
    
      },
     
    
     
    
 },{ versionKey: false });

 
module.exports = mongoose.model('admin',Admin);