const mongoose = require('mongoose')

const Schema = mongoose.Schema;
 var LeaveTypes = new Schema({
    
   email:{
    type:String
   },
    CasualLeave:{
        type:String
    },
    SickLeave:{
        type:String
    },
     
    VacationLeave:{
        type:String
    },
     
    PersonalLeave:{
        type:String
    }
    
     
    
 },{ versionKey: false });

 
module.exports = mongoose.model('LeaveTypes',LeaveTypes);