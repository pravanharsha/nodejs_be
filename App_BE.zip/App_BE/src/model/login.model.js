const mongoose = require('mongoose')

const Schema = mongoose.Schema;
var Login = new Schema({
  email: {
    type: String,
    required: true,


  },employeeName:{
    type:String,
   
  }
  ,
  password: {
    type: String,
    required: true

  }, CasualLeave:{
    type:String
},
SickLeave:{
    type:String
},
 
VacationLeave:{
    type:Number
},
 
PersonalLeave:{
    type:Number
},
 
}, { versionKey: false });


module.exports = mongoose.model('Login', Login);