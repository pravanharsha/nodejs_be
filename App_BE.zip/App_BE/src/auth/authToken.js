
module.exports = function verify(req,res,next){

    const bearerHeader = req.headers['authorization'];
    console.log("bearerHeader",bearerHeader)
     if(typeof bearerHeader !== 'undefined'){
         const bearer = bearerHeader.split(" ");
         const authToken = bearer[1];
         console.log(bearer[1],"bearer[1]")
         console.log("token",authToken)
          req.token= authToken;
          console.log(req.token,"llll")
         next();
     }else{
         res.send({
             result:'Token is invalid'
         })
 
     }
 
 }