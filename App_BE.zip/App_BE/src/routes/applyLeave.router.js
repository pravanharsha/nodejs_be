const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser');
const Login = require('../model/login.model')
const AppliedLeave = require('../model/leave.model')
const LeaveInfo = require('../model/LeaveInfo.model')
const LeaveTypes = require('../model/leave.model');
const loginModel = require('../model/login.model');
const verify = require('../auth/authToken')
var jwt = require('jsonwebtoken');
const jwtSerect = "LeaveApplication"


router.post('/ApplyLeave', async (req, res) => {
  
   
    try {
       
        await LeaveInfo.create({
            email: req.body.email,
            intialDate: req.body.intialDate,
            finalDate: req.body.finalDate,
            totalDays: req.body.totaldays,
            reasonForLeave: req.body.reasonForLeave,
            typeofLeave: req.body.typeofLeave,
            leaveStatus:req.body.leaveStatus,
            associateName:req.body.associateName
        }).then(res.json({ success: true ,status:"pending"}))

    } catch (err) {
        return res.json({ success: false, err }),
            console.log(err)
    }
})



router.patch('/Updateleaves',verify, async (req, res) => {
    console.log(req.body)
   const x=  jwt.verify(req.token,jwtSerect) 
   console.log(x,"xxx")    
        
   
            const userEmail = req.body.email
            let data = req.body.data;
            console.log(data.selectedLeaveType)
            console.log(data.diffDays)
            const UserData = await Login.findOne({ email: req.body.email })
            const userId = UserData.id
            const updatedDays =( UserData[data.selectedLeaveType] - data.diffDays);
            console.log("data.selectedLeaveType",updatedDays)
            const updatevalue = {}
            updatevalue[data.selectedLeaveType] = updatedDays;
            console.log("Updateleaves", updatevalue)
            
           
            try {
                const userUpdatedValue = await Login.updateOne({ email: req.body.email}, { $set: {[data.selectedLeaveType]:updatedDays} });       
                    console.log(userUpdatedValue,"userUpdatedValue")
                return res.json({ success:true })
        
            }
            catch (err) {
                console.log(err, "err")
            }

        })


router.post('/getLeavesHistory' , async(req,res)=>{
    try{
    const leavesHistory = await LeaveInfo.find({ email: req.body.email })
               

            return  res.send({ leavesHistory,success:true})


    }
    catch(err){
        console.log(err);
       return res.send(err)
    }

})













module.exports = router;