const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser');
const Login = require('../model/login.model')
const bcrypt = require('bcryptjs')
const jwtSerect = "LeaveApplication"
var jwt = require('jsonwebtoken');
const verify = require('../auth/authToken')
const { use } = require('./applyLeave.router');

router.post('/getUserData',async (req, res) => {
    try {
        const UserData = await Login.findOne({ email: req.body.email });

        const responseDetails = {
            id: UserData._id,
            email: UserData.email,
            PersonalLeave: UserData.PersonalLeave,
            SickLeave: UserData.SickLeave,
            CasualLeave: UserData.CasualLeave,
            VacationLeave: UserData.VacationLeave
        }
        console.log(UserData,"userData")
        console.log(responseDetails,"responseDetails")

        return res.json({ responseDetails })
    } catch (err) {
        return res.json({ success: false, err })
    }

})



router.post('/Login', async (req, res) => {
console.log(req.body," login")
    try {
        const userEmail = req.body.email;

        const loginUserData = await Login.findOne({ email: userEmail });
        console.log("loginUserData",loginUserData)
 
        const pwdCompare = await bcrypt.compare(req.body.password, loginUserData.password)

 console.log(" compare ",pwdCompare)
        if (!pwdCompare) {
            return res.status(400).json({ errors: "Try login with  correct Credentialss" })
        }

        const data = {
            user: {
                id: loginUserData.id
            }

        }
        console.log(data, " tokendata")

        const authToken = jwt.sign(data, jwtSerect,{expiresIn: '1d'})
        
      const userData = {
        associateName : loginUserData.employeeName
      }

        return res.json({ success: true, authToken: authToken,userData })
    }
    catch (error) {
        console.log(error)
        return res.status(404).json({ errors: "Try with correct Credentialhhhhhhhhhhhhs" })
    }
}
)

router.post('/EmailDuplicateCheck', async (req, res) => {
    const userEmail = req.body.email;
    try {
        const loginUserData = await Login.findOne({ email: userEmail });
        if (loginUserData) {
            console.log(loginUserData, "loginUserDatattttt")
            return res.json({ success: true, message: "Already registered" })
        } else {
            return res.json({ success: false, message: "Not registered" })
        }



    } catch (err) {
        console.log(err)
    }
})




router.post('/SignUp', async (req, res) => {
    const salt = await bcrypt.genSalt(15)
    const securedPassword = await bcrypt.hash(req.body.password, salt)
    try {
        await Login.create({
            email: req.body.email,
            password: securedPassword,
            employeeName: req.body.empolyeeName,
            CasualLeave: req.body.CasualLeave,
            PersonalLeave: req.body.PersonalLeave,
            SickLeave: req.body.SickLeave,
            VacationLeave: req.body.VacationLeave

        })
            .then(res.json({ success: true }))

    } catch (err) {
        console.log(err)
    }
})
router.patch('/Login/:id',verify, async (req, res) => {
    const userId = req.params.id;

    const loginUserData = await Login.findOne({ id: userId });

    loginUserData.VacationLeave = req.body.VacationLeave
    try {
        const user = await loginUserData.save();
        res.send(user)
        console.log(user, "userrrrr")
    } catch (err) {
        res.send(err)
    }

})







module.exports = router;