
const express = require('express')
const router = express.Router()
var jwt = require('jsonwebtoken');
const jwtSerect = "LeaveApplication"
const bcrypt = require('bcryptjs')
const verify = require('../auth/authToken')
const Admin = require('../model/admin.model');
const LeaveInfoModel = require('../model/LeaveInfo.model');

router.post("/Login", async (req, res) => {
    console.log(req.body, " admin login ")
    try {
        const userEmail = req.body.email;

        const loginUserData = await Admin.findOne({ email: userEmail });
        console.log("loginUserData", loginUserData)


        const pwdCompare = await bcrypt.compare(req.body.password, loginUserData.password)

        console.log(" compare ", pwdCompare)
        if (!pwdCompare) {
            return res.status(400).json({ errors: "Try login with  correct Credentialss" })
        }

        const data = {
            user: {
                id: loginUserData._id
            }

        }
        console.log(data, " tokendata")

        const authToken = jwt.sign(data, jwtSerect)
        return res.json({ success: true, authToken: authToken })
    }
    catch (error) {
        console.log(error)
        return res.status(404).json({ errors: "Try with correct Credentialhhhhhhhhhhhhs" })

    }
})

router.post('/SignUp', async (req, res) => {
    const salt = await bcrypt.genSalt(15)
    const securedPassword = await bcrypt.hash(req.body.password, salt)
    console.log(req.body)
    try {
        await Admin.create({
            email: req.body.email,
            password: securedPassword,
            adminName: req.body.adminName,
        })
        return res.json({ success: true })


    } catch (err) {
        console.log(err)
        return res.json({ success: false })

    }
})
router.get('/getAllData',async (req,res)=>{
    try{
        const response = await LeaveInfoModel.find()
    }catch(err){

    }

})


router.post('/EmailDuplicateCheck', async (req, res) => {
    const userEmail = req.body.email;
    try {
        const loginUserData = await Admin.findOne({ email: userEmail });
        if (loginUserData) {
            console.log(loginUserData, "loginUserDatattttt")
            return res.json({ success: true, message: "Already registered" })
        } else {
            return res.json({ success: false, message: "Not registered" })
        }



    } catch (err) {
        console.log(err)
    }
})


module.exports = router;