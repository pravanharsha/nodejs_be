const express = require('express')
const router = express.Router()
const Login = require('../model/login.model')

var jwt = require('jsonwebtoken');
const LeaveInfoModel = require('../model/LeaveInfo.model');
const jwtSerect = "LeaveApplication"


router.get('/allAssociates', async (req, res) => {
    const allAssociates = await LeaveInfoModel.find()
 
 console.log(allAssociates)
    return res.send({ allAssociates, success: true })



})

router.post('/associateData',async(req,res)=>{
   
    const associateId = req.body._id;
   
    try{
        const response = await LeaveInfoModel.findById(associateId)
        return res.send({ response, success: true })
    }
    
    catch(err){

    }
})

router.patch('/updateAssociateLeaveResponse',async(req,res)=>{
    console.log(req.body)
    const userId = req.body._id
   const updatedData = req.body.data
   console.log(updatedData,"data ")

    try {
        const userUpdatedValue = await LeaveInfoModel.updateOne({_id:userId }, { $set: updatedData});       
            console.log(userUpdatedValue,"userUpdatedValue")
        return res.json({ success:true })

    }
    catch (err) {
        console.log(err, "err")
    }
})



module.exports = router;