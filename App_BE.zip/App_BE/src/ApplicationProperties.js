const targetUrl = 'http://localhost:3000';
const targetUrlAdmin = 'http://localhost:3000/Admin';
module.exports={
    targetUrl,
    targetUrlAdmin
}