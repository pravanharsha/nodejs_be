const express = require('express')
const mongoose = require('mongoose')
const ApplicationProperties = require('./src/ApplicationProperties')
const cors = require('cors')
const app = express();

app.use(cors())

MANGO_URI = "mongodb://localhost:27017/Pravan_App"

mongoose.connect(MANGO_URI, { useNewUrlParser: true });
const connect = mongoose.connection

connect.on('open', function () {
   console.log("connected ")
})

app.use((req, res, next) => {

   res.setHeader(
      "Access-Control-Allow-Methods",
        "OPTIONS, GET, POST, PUT, PATCH, DELETE",
      "Access-Control-Allow-Origin", `${ApplicationProperties.targetUrl}`, `${ApplicationProperties.targetUrlAdmin}`, '*')
   res.header(
      "Access-Control-Allow-Headers",
      "Origin , X-Requested-With,Content-Type,Accept");
   next();



})

app.use(express.json())
const allAssociatesRouter = require('./src/routes/allAssociates.router')
app.use('/Admin',allAssociatesRouter)

const AdminRouter = require('./src/routes/adminRouter')
app.use('/Admin', AdminRouter)
const loginRouter = require('./src/routes/login.router')
app.use('/', loginRouter)

const LeaveRouter = require('./src/routes/applyLeave.router')
app.use('/', LeaveRouter)





app.listen(8080, () => {

   console.log(" server started");
})
